import React from "react";
import "./food.css";
import { Link } from "react-router-dom";

const Food = () => {
  // const { count } = props;
  return (
    <div>
      {/* <div className="food">
        <div className="head">
          <h1>
            <Link to="/Main">Food's Restaurant</Link>
          </h1>
          <Link to="Order">
            <i class="fa-solid fa-cart-shopping"></i>
          </Link>
          <strong>{count}</strong>
        </div>
      </div> */}
    </div>
  );
};

export default Food;
