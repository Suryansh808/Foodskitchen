import React from "react";
import "./Last.css";

const Lastpage = () => {
  return (
    <div>
      <h1 className="lasth1">Thankyou for your Order</h1>{" "}
    </div>
  );
};

export default Lastpage;
